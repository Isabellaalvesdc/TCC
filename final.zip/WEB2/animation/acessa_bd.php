<?php
$indice = intval($_GET['indice']);

$con = mysqli_connect('localhost','root','','tcc');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"ajax_demo");
//$sql="SELECT * FROM concetacao_gee WHERE id = '".$q."'";
$sql="SELECT * FROM concentracao_gee WHERE indice = '".$indice."'";
$result = mysqli_query($con,$sql);

while($row = mysqli_fetch_array($result)) {
   echo $row['temp'] . ";" . $row['nivel_mar'];
}
mysqli_close($con);
?>